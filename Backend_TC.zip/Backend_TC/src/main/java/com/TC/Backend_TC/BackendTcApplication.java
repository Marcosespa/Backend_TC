package com.TC.Backend_TC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTcApplication.class, args);
	}

}
