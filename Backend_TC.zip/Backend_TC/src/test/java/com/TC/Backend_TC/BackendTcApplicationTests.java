package com.TC.Backend_TC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTcApplicationTests {

	@Test
	void contextLoads() {
	}

}
